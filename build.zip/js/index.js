// include your scripts here 
$(window).on("load", function () {
const enableMenuScroll = (sliderId, itemsClass, stepLengths) => {
    const options = {
        horizontal: 1,
        speed: 300,
        mouseDragging: 1,
        touchDragging: 1,
        easing: "swing",
        releaseSwing: true,
        swingSpeed: 0.5,
    };
    const slider = new Sly("#" + sliderId, options).init();

    $("." + itemsClass).each((idx, item) => {
        $(item).click(() => {
            slider.slideTo(stepLengths[idx])
        })
    })
}

const toggleActiveClass = (e, selector, activeClassName) => {
    $(selector).removeClass(activeClassName)
    const curItem = $(e.currentTarget)
    curItem.addClass(activeClassName)
}

if (window.matchMedia("(max-width: 425px)").matches) {
    enableMenuScroll("menu-row", "menu__item", [0, 55, 150])
}
if (window.matchMedia("(max-width: 830px)").matches) {
    enableMenuScroll("types-row-plintus", "types__item", [0, 80, 170, 210])
    enableMenuScroll("types-row-trim", "types__item_trim", [0, 80, 170, 210])
}

$(".menu__item").on("click", (e) => toggleActiveClass(e, ".menu__item", "menu__item_active"))
$("#building_plintus .types__item").on("click", (e) => {
    const id = $(e.currentTarget).attr("id")
    switch (id) {
        case "plintus-evro":
            buildingData.form = "Евро"
            break
        case "plintus-evro-streight":
            buildingData.form = "Евро (прямой)"
            break
        case "plintus-boot":
            buildingData.form = "Сапожок"
            break
        case "plintus-figure":
            buildingData.form = "Фигурный"
            break
        default:
            break
    }
    toggleActiveClass(e, "#building_plintus .types__item", "types__item_active")
})
$("#building_trim .types__item").on("click", (e) => {
    const id = $(e.currentTarget).attr("id")
    switch (id) {
        case "trim-evro":
            buildingData.form = "Евро"
            break
        case "trim-evro-streight":
            buildingData.form = "Евро (прямой)"
            break
        case "trim-semicircular":
            buildingData.form = "Полукруглый"
            break
        case "plintus-figure":
            buildingData.form = "Фигурный"
            break
        default:
            break
    }
    toggleActiveClass(e, "#building_trim .types__item", "types__item_active")
})
$("#building_rake .types__item").on("click", (e) => {
    const id = $(e.currentTarget).attr("id")
    switch (id) {
        case "rake-with-groove":
            buildingData.form = "С пазом"
            break
        case "rake-without-groove":
            buildingData.form = "Без паза"
            break
        default:
            break
    }
    toggleActiveClass(e, "#building_rake .types__item", "types__item_active")
})
$("#building_rake .material__item").on("click", (e) => toggleActiveClass(e, "#building_rake .material__item", "material__item_active"))
$("#building_plintus .material__item").on("click", (e) => toggleActiveClass(e, "#building_plintus .material__item", "material__item_active"))
$("#building_trim .material__item").on("click", (e) => toggleActiveClass(e, "#building_trim .material__item", "material__item_active"))
$(".style__span").on("click", (e) => toggleActiveClass(e, ".style__span", "style__span_active"))

$(window).scroll(function () {
    // make menu fixed on top
    const menuOffset = document.querySelector(".menu").offsetTop + window.innerHeight
    const finalBlockOffset = document.querySelector("#hide-menu").offsetTop + window.innerHeight
    const fakeMenuOffset = document.querySelector(".menu_fake").offsetTop + window.innerHeight
    if ($(window).scrollTop() >= menuOffset && $(window).scrollTop() <= finalBlockOffset) {
        $('.menu_fake').css("display", "block");
        $('.menu').addClass('_fixed');
    }
    if ($(window).scrollTop() <= fakeMenuOffset || $(window).scrollTop() > finalBlockOffset) {
        $('.menu').removeClass('_fixed');
        $('.menu_fake').css("display", "none");
    }
})

const linkClasses = ".menu__track, .liquidation__buttons"

$(linkClasses).on('click', '[href^="#"]', async function (e) {
    // плавная прокрутка до якоря
    e.preventDefault()
    isAllowedAutoSwitching = false

    await $('html,body').animate({
        scrollTop: $(this.hash).offset().top - 100
    }, 500, "swing", () => isAllowedAutoSwitching = true);

});

let lastScrollTop = 0;
const ids = ["plintus", "rake", "trim"] // массив id блоков
let isAllowedAutoSwitching = true; // разрешено ли автопролистывание меню
let currentIndex = 0 // индекс текущего блока
let lastCurrentIndex = 0

$(window).on("scroll", function () {
    // автопереключение пунктов меню
    let scrollTop = $(this).scrollTop();

    if (!isAllowedAutoSwitching) return

    if (scrollTop > lastScrollTop) {
        // скролл вниз
        let i = currentIndex
        while (isVisibleForScrollDown("#" + ids[i] + "-start")) {
            // идем вниз до по стартовым чекпоинтам, пока не дойдем до первого не видимого
            ++i
        }
        if (i === -1 || i === 0) currentIndex = 0
        else currentIndex = i - 1

    } else {
        // скролл вверх
        let i = currentIndex
        while (isVisibleForScrollUp("#" + ids[i] + "-end")) {
            --i
        }
        if (i === 3) currentIndex = 2
        else currentIndex = i + 1
    }

    if (lastCurrentIndex !== currentIndex) {
        lastCurrentIndex = currentIndex
        isAllowedAutoSwitching = false
        $(".menu__item").removeClass("menu__item_active")
        $("#menu-" + ids[currentIndex]).addClass("menu__item_active")

        setTimeout(() => {
            isAllowedAutoSwitching = true
        }, 300)

    }
    lastScrollTop = scrollTop;
})


function isVisibleForScrollDown(id) {
    // console.log("id: ", id)

    const element = $(id)

    if (!element.offset()) return

    const elementTop = $(element).offset().top; // позиция элемента от верхнего края документа
    const viewportTop = $(window).scrollTop(); // значение отступа прокрутки сверху 
    const viewportBottom = viewportTop + $(window).height();

    // $('#scanner').remove()
    // $('#body').append('<div id="scanner"></div>');

    // const props = {
    //     background: "#000",
    //     opacity: 0.5,
    //     position: "fixed",
    //     width: "100%",
    //     height: "10px",
    //     top: $(window).height() / 2 + "px",
    // }
    // $("#scanner").css(props)


    return elementTop < viewportTop + $(window).height() / 2
}

function isVisibleForScrollUp(id) {

    const element = $(id)

    if (!element.offset()) return

    const elementTop = $(element).offset().top; // позиция элемента от верхнего края документа
    const viewportTop = $(window).scrollTop(); // значение отступа прокрутки сверху 
    const viewportBottom = viewportTop + $(window).height();


    return elementTop > viewportTop + $(window).height() / 2
}
let isSafari = false,
    isExplorer = false

// CHROME
if (navigator.userAgent.indexOf("Chrome") != -1) {
    console.log("Google Chrome");
}
// FIREFOX
else if (navigator.userAgent.indexOf("Firefox") != -1) {
    console.log("Mozilla Firefox");
}
// INTERNET EXPLORER
else if (navigator.userAgent.indexOf("MSIE") != -1) {
    isExplorer = true
}
// EDGE
else if (navigator.userAgent.indexOf("Edge") != -1) {
    console.log("Internet Exploder");
}
// SAFARI
else if (navigator.userAgent.indexOf("Safari") != -1) {
    isSafari = true
}
// OPERA
else if (navigator.userAgent.indexOf("Opera") != -1) {
    console.log("Opera");
}
// YANDEX BROWSER
else if (navigator.userAgent.indexOf("YaBrowser") != -1) {
    console.log("YaBrowser");
}
// OTHERS
else {
    console.log("Others");
}

if (isSafari || isExplorer) {
    $(".discounts__slider").addClass("safari")
    $(".safari").removeClass("discounts__slider")
    $('.discounts__slider').slick("unslick")
} else {
    $('.discounts__slider').slick({
        adaptiveHeight: true,
        autoplay: true,
        arrows: false,
        dots: true,
        centerMode: true,
        focusOnSelect: true,
        variableWidth: true,
        speed: 400,
    })
}
const rangeValueToThicknessPlintus = (category, type, value) => {
    if (category === "mdf") {
        switch (type) {
            case "dyed":
                switch (+value) {
                    case 1:
                        return 10
                    case 3:
                        return 12
                    case 5:
                        return 16
                    case 7:
                        return 18
                    default:
                        return 10
                }
        }
    } else {
        switch (type) {
            case "oak":
            case "ash":
            case "beech":
                switch (+value) {
                    case 1:
                        return 12
                    case 3:
                        return 14
                    case 5:
                        return 16
                    case 7:
                        return 18
                    case 9:
                        return 20
                    case 11:
                        return 22
                    default:
                        return 12
                }
        }
    }
}
const rangeValueToHeightPlintus = (category, type, value) => {
    if (category === "mdf") {
        switch (type) {
            case "dyed":
                switch (+value) {
                    case 1:
                        return 70
                    case 3:
                        return 80
                    case 5:
                        return 100
                    case 7:
                        return 120
                    case 9:
                        return 150
                    default:
                        return 70
                }
        }
    } else {
        switch (type) {
            case "oak":
            case "ash":
            case "beech":
                switch (+value) {
                    case 1:
                        return 70
                    case 3:
                        return 80
                    case 5:
                        return 90
                    case 7:
                        return 100
                    case 9:
                        return 120
                    default:
                        return 70
                }
        }
    }
}
const rangeValueToHeightRake = (category, type, value) => {
    if (category === "mdf") {
        switch (type) {
            case "dyed":
                switch (+value) {
                    case 1:
                        return 20
                    case 3:
                        return 30
                    case 5:
                        return 40
                    case 7:
                        return 50
                    case 9:
                        return 60
                    case 11:
                        return 80
                    case 13:
                        return 90
                    case 15:
                        return 100
                    default:
                        return 20
                }
        }
    } else {
        switch (type) {
            case "oak":
            case "ash":
            case "beech":
                switch (+value) {
                    case 1:
                        return 30
                    case 3:
                        return 40
                    case 5:
                        return 50
                    case 7:
                        return 60
                    default:
                        return 30
                }
        }
    }
}
const rangeValueToThicknessRake = (category, type, value) => {
    if (category === "mdf") {
        switch (type) {
            case "dyed":
                switch (+value) {
                    case 1:
                        return 20
                    case 3:
                        return 25
                    case 5:
                        return 30
                    case 7:
                        return 40
                    case 9:
                        return 50
                    default:
                        return 20
                }
        }
    } else {
        switch (type) {
            case "oak":
            case "ash":
            case "beech":
                switch (+value) {
                    case 1:
                        return 20
                    case 3:
                        return 25
                    case 5:
                        return 40
                    case 7:
                        return 45
                    default:
                        return 12
                }
        }
    }
}
const rangeValueToHeightTrim = (category, type, value) => {
    if (category === "mdf") {
        switch (type) {
            case "dyed":
                switch (+value) {
                    case 1:
                        return 60
                    case 3:
                        return 70
                    case 5:
                        return 80
                    case 7:
                        return 90
                    case 9:
                        return 100
                    default:
                        return 60
                }
        }
    } else {
        switch (type) {
            case "oak":
            case "ash":
            case "beech":
                switch (+value) {
                    case 1:
                        return 60
                    case 3:
                        return 70
                    case 5:
                        return 80
                    case 7:
                        return 90
                    case 9:
                        return 100
                    default:
                        return 30
                }
        }
    }
}
const rangeValueToThicknessTrim = (category, type, value) => {
    if (category === "mdf") {
        switch (type) {
            case "dyed":
                switch (+value) {
                    case 1:
                        return 10
                    case 3:
                        return 12
                    case 5:
                        return 16
                    case 7:
                        return 18
                    default:
                        return 20
                }
        }
    } else {
        switch (type) {
            case "oak":
                switch (+value) {
                    case 1:
                        return 12
                    case 3:
                        return 14
                    case 5:
                        return 16
                    case 7:
                        return 20
                    default:
                        return 12
                }
            case "ash":
            case "beech":
                switch (+value) {
                    case 1:
                        return 10
                    case 3:
                        return 12
                    case 5:
                        return 16
                    case 7:
                        return 18
                    default:
                        return 10
                }
        }
    }
}
const chahgeSubmitButtonText = () => {
    if (window.matchMedia("(min-width: 820px)").matches) {
        $(".building__btn").html("Отправить")
    }
}
$(".material__item").on("click", (e) => {
    const target = $(e.target)
    if (target.attr("id") === "mdf") {
        $(".building__style").removeClass("_hidden")
    } else {
        $(".building__style").addClass("_hidden")
    }
})

chahgeSubmitButtonText()

$(window).resize(chahgeSubmitButtonText)

const buildingData = {
	name: "Плинтус",
	category: "МДФ",
	form: "Евро",
	type: "Выкрашенный",
	thickness: 12,
	height: 70,
	metres: 1,
}
class Plintus {
    constructor() {
        this._category = "mdf"
        this._type = "dyed"
        this._thickness = 12
        this._height = 70
        this._metres = 1
    }
    _setPrice = (value) => {
        $("#building_plintus .size__price").html(`<p>${value} ₽</p>`)
    }
    _setCorrectPrice = () => {
        let price;
        if (this._category === "tree") {
            price = getItemFromTree(plintusTree, [this._type, this._thickness, this._height])
        } else {
            price = getItemFromTree(plintusMDF, [this._type, this._thickness, this._height])
        }
        price *= this._metres
        this._setPrice(price)
    }
    setValue(field, value) {
        switch (field) {
            case "category":
                this._category = value
                break
            case "type":
                this._type = value
                break
            case "thickness":
                this._thickness = value
                break
            case "height":
                this._height = value
                break
            case "metres":
                this._metres = value
                break
            default:
                return
        }
        // console.log("category: ", this._category);
        // console.log("type: ", this._type);
        // console.log("thickness: ", this._thickness);
        // console.log("height: ", this._height);
        // console.log("metres: ", this._metres);
        this._setCorrectPrice()
    }
}

const plintus = new Plintus()

const setRangeValues = (selector, values) => {
    const $elem = $(selector)
    let html = ""
    values.forEach(value => {
        html += `<div>${value}</div>`
    })
    $elem.html(html)

}
const setRangeStyle = (selector, count) => {
    const $elem = $(selector)
    switch (count) {
        case 4:
            $elem.attr("max", "8")
            return
        case 5:
            $elem.attr("max", "10")
            return
        case 6:
            $elem.attr("max", "12")
            return
        case 8:
            $elem.attr("max", "16")
            return
        default:
            return
    }
}

$("#building_plintus .material__item").on("click", (e) => {
    const id = $(e.target).attr("id")
    if (id === "mdf") {
        plintus.setValue("type", "dyed")
        plintus.setValue("category", "mdf")
        setRangeValues("#building_plintus ._thickness", [10, 12, 16, 18])
        setRangeStyle("#range-thickness-plintus", 4)
        setRangeValues("#building_plintus ._height", [70, 80, 100, 120, 150])
        setRangeStyle("#range-height-plintus", 5)
        buildingData.category = "МДФ"
        buildingData.type = "Выкрашенный"
    } else {
        plintus.setValue("type", id)
        plintus.setValue("category", "tree")
        setRangeValues("#building_plintus ._thickness", [12, 14, 16, 18, 20, 22])
        setRangeStyle("#range-thickness-plintus", 6)
        setRangeValues("#building_plintus ._height", [70, 80, 90, 100, 120])
        setRangeStyle("#range-height-plintus", 5)
        buildingData.category = "Массив"
        switch (id) {
            case "oak":
                buildingData.type = "Дуб"
                break
            case "ash":
                buildingData.type = "Ясень"
                break
            case "beech":
                buildingData.type = "Бук"
                break
            default:
                break
        }
    }
    initRangeFillLower()
})
$("#building_plintus .style__span").on("click", (e) => {
    const type = $(e.target).attr("id")
    plintus.setValue("type", type)
})

const createSetCorrectInputValue = (selector) => {
    let prevValue;
    return () => {
        const $input = $(selector)
        let value = +$input.val()
        const maxValue = +$input.attr("max")
        const minValue = +$input.attr("min")
        if (value % 2 === 0) {
            if (value === maxValue) {
                $input.val(value = maxValue - 1)
            } else if (value === minValue) {
                $input.val(value = minValue + 1)
            } else if (prevValue > value) {
                $input.val(--value)
            } else {
                $input.val(++value)
            }
        } else {
            prevValue = value
        }
        return value
    }
}
$("#range-thickness-plintus").on("input", (e) => {
    const setCorrectInputValue = createSetCorrectInputValue(e.target)
    const value = setCorrectInputValue()
    const thickness = rangeValueToThicknessPlintus(plintus._category, plintus._type, value)
    $("#building_plintus .thickness-mm").html(thickness + " мм.")
    plintus.setValue("thickness", thickness)
    buildingData.thickness = thickness
})

$("#range-height-plintus").on("input", (e) => {
    const setCorrectInputValue = createSetCorrectInputValue(e.target)
    const value = setCorrectInputValue()
    const height = rangeValueToHeightPlintus(plintus._category, plintus._type, value)
    $("#building_plintus .height-mm").html(height + " мм.")
    plintus.setValue("height", height)
    buildingData.height = height
})
$("#building_plintus .size__input").on("input", (e) => {
    const value = e.target.value
    plintus.setValue("metres", value)
    buildingData.metres = value
})
class Rake {
    constructor() {
        this._category = "mdf"
        this._type = "dyed"
        this._thickness = 12
        this._height = 70
        this._metres = 1
    }
    _setPrice = (value) => {
        $("#building_rake .size__price").html(`<p>${value} ₽</p>`)
    }
    _setCorrectPrice = () => {
        let price;
        if (this._category === "tree") {
            price = getItemFromTree(rakeTree, [this._type, this._thickness, this._height])
        } else {
            price = getItemFromTree(rakeMDF, [this._type, this._thickness, this._height])
        }
        price *= this._metres
        this._setPrice(price)
    }
    setValue(field, value) {
        switch (field) {
            case "category":
                this._category = value
                break
            case "type":
                this._type = value
                break
            case "thickness":
                this._thickness = value
                break
            case "height":
                this._height = value
                break
            case "metres":
                this._metres = value
                break
            default:
                return
        }
        // console.log("category: ", this._category);
        // console.log("type: ", this._type);
        // console.log("thickness: ", this._thickness);
        // console.log("height: ", this._height);
        // console.log("metres: ", this._metres);
        this._setCorrectPrice()
    }
}

const rake = new Rake()

$("#building_rake .material__item").on("click", (e) => {
    const id = $(e.target).attr("id")
    console.log("hello");
    if (id === "mdf") {
        rake.setValue("type", "dyed")
        rake.setValue("category", "mdf")
        setRangeValues("#building_rake ._thickness", [20, 25, 30, 40, 50])
        setRangeStyle("#range-thickness-rake", 5)
        setRangeValues("#building_rake ._height", [20, 30, 40, 50, 60, 80, 90, 100])
        setRangeStyle("#range-height-rake", 8)
        buildingData.category = "МДФ"
        buildingData.type = "Выкрашенный"
    } else {
        rake.setValue("type", id)
        rake.setValue("category", "tree")
        setRangeValues("#building_rake ._thickness", [20, 25, 40, 45])
        setRangeStyle("#range-thickness-rake", 4)
        setRangeValues("#building_rake ._height", [30, 40, 50, 60])
        setRangeStyle("#range-height-rake", 4)
        buildingData.category = "Массив"
        switch (id) {
            case "oak":
                buildingData.type = "Дуб"
                break
            case "ash":
                buildingData.type = "Ясень"
                break
            case "beech":
                buildingData.type = "Бук"
                break
            default:
                break
        }
    }
    initRangeFillLower()
})
$("#building_rake .style__span").on("click", (e) => {
    const type = $(e.target).attr("id")
    rake.setValue("type", type)
})
$("#range-thickness-rake").on("input", (e) => {
    const setCorrectInputValue = createSetCorrectInputValue(e.target)
    const value = setCorrectInputValue()
    const thickness = rangeValueToThicknessRake(rake._category, rake._type, value)
    $("#building_rake .thickness-mm").html(thickness + " мм.")
    rake.setValue("thickness", thickness)
    buildingData.thickness = thickness
})

$("#range-height-rake").on("input", (e) => {
    const setCorrectInputValue = createSetCorrectInputValue(e.target)
    const value = setCorrectInputValue()
    const height = rangeValueToHeightRake(rake._category, rake._type, value)
    $("#building_rake .height-mm").html(height + " мм.")
    rake.setValue("height", height)
    buildingData.height = height
})
$("#building_rake .size__input").on("input", (e) => {
    const value = e.target.value
    rake.setValue("metres", value)
    buildingData.metres = value
})
class Trim {
    constructor() {
        this._category = "mdf"
        this._type = "dyed"
        this._thickness = 26
        this._height = 80
        this._metres = 1
    }
    _setPrice = (value) => {
        $("#building_trim .size__price").html(`<p>${value} ₽</p>`)
    }
    _setCorrectPrice = () => {
        let price;
        if (this._category === "tree") {
            price = getItemFromTree(trimTree, [this._type, this._thickness, this._height])
        } else {
            price = getItemFromTree(trimMDF, [this._type, this._thickness, this._height])
        }
        price *= this._metres
        this._setPrice(price)
    }
    setValue(field, value) {
        switch (field) {
            case "category":
                this._category = value
                break
            case "type":
                this._type = value
                break
            case "thickness":
                this._thickness = value
                break
            case "height":
                this._height = value
                break
            case "metres":
                this._metres = value
                break
            default:
                return
        }
        // console.log("category: ", this._category);
        // console.log("type: ", this._type);
        // console.log("thickness: ", this._thickness);
        // console.log("height: ", this._height);
        // console.log("metres: ", this._metres);
        this._setCorrectPrice()
    }
}

const trim = new Trim()

$("#building_trim .material__item").on("click", (e) => {
    const id = $(e.target).attr("id")
    console.log("hello");
    if (id === "mdf") {
        trim.setValue("type", "dyed")
        trim.setValue("category", "mdf")
        setRangeValues("#building_trim ._thickness", [10, 12, 16, 18])
        setRangeStyle("#range-thickness-trim", 4)
        setRangeValues("#building_trim ._height", [60, 70, 80, 90, 100])
        setRangeStyle("#range-height-trim", 5)
        buildingData.category = "МДФ"
        buildingData.type = "Выкрашенный"
    } else {
        trim.setValue("type", id)
        trim.setValue("category", "tree")
        setRangeValues("#building_trim ._thickness", [10, 12, 16, 18])
        setRangeStyle("#range-thickness-trim", 4)
        setRangeValues("#building_trim ._height", [60, 70, 80, 90, 100])
        setRangeStyle("#range-height-trim", 5)
        if (id === "oak") {
            setRangeValues("#building_trim ._thickness", [12, 14, 16, 20])
        }
        buildingData.category = "Массив"
        switch (id) {
            case "oak":
                buildingData.type = "Дуб"
                break
            case "ash":
                buildingData.type = "Ясень"
                break
            case "beech":
                buildingData.type = "Бук"
                break
            default:
                break
        }
    }
    initRangeFillLower()
})
$("#building_trim .style__span").on("click", (e) => {
    const type = $(e.target).attr("id")
    trim.setValue("type", type)
})
$("#range-thickness-trim").on("input", (e) => {
    const setCorrectInputValue = createSetCorrectInputValue(e.target)
    const value = setCorrectInputValue()
    const thickness = rangeValueToThicknessTrim(trim._category, trim._type, value)
    $("#building_trim .thickness-mm").html(thickness + " мм.")
    trim.setValue("thickness", thickness)
    buildingData.thickness = thickness
})
$("#range-height-trim").on("input", (e) => {
    const setCorrectInputValue = createSetCorrectInputValue(e.target)
    const value = setCorrectInputValue()
    const height = rangeValueToHeightTrim(trim._category, trim._type, value)
    $("#building_trim .height-mm").html(height + " мм.")
    trim.setValue("height", height)
    buildingData.height = height
})
$("#building_trim .size__input").on("input", (e) => {
    const value = e.target.value
    trim.setValue("metres", value)
    buildingData.metres = value
})
const plintusTree = {
    oak: {
        12: {
            70: 250,
            80: 288,
            90: 300,
            100: 330,
            120: 382,
        },
        14: {
            70: 294,
            80: 336,
            90: 350,
            100: 385,
            120: 446,
        },
        16: {
            70: 336,
            80: 384,
            90: 400,
            100: 440,
            120: 510,
        },
        18: {
            70: 378,
            80: 432,
            90: 450,
            100: 495,
            120: 573,
        },
        20: {
            70: 450,
            80: 480,
            90: 500,
            100: 550,
            120: 640,
        },
        22: {
            70: 462,
            80: 528,
            90: 550,
            100: 605,
            120: 700,
        },
    },
    ash: {
        12: {
            70: 274,
            80: 288,
            90: 300,
            100: 315,
            120: 330,
        },
        14: {
            70: 320,
            80: 336,
            90: 350,
            100: 367,
            120: 385,
        },
        16: {
            70: 365,
            80: 384,
            90: 400,
            100: 420,
            120: 440,
        },
        18: {
            70: 411,
            80: 432,
            90: 450,
            100: 472,
            120: 495,
        },
        20: {
            70: 457,
            80: 480,
            90: 500,
            100: 525,
            120: 550,
        },
        22: {
            70: 500,
            80: 528,
            90: 550,
            100: 577,
            120: 605,
        },
    },
    beech: {
        12: {
            70: 158,
            80: 175,
            90: 195,
            100: 210,
            120: 239,
        },
        14: {
            70: 184,
            80: 205,
            90: 227,
            100: 245,
            120: 278,
        },
        16: {
            70: 211,
            80: 235,
            90: 260,
            100: 280,
            120: 318,
        },
        18: {
            70: 237,
            80: 266,
            90: 292,
            100: 315,
            120: 358,
        },
        20: {
            70: 264,
            80: 295,
            90: 325,
            100: 350,
            120: 398,
        },
        22: {
            70: 290,
            80: 325,
            90: 355,
            100: 385,
            120: 438,
        },
    },
}
const plintusMDF = { // временно категории уходят, поэтому все цены на МДФ в dyed
    finish: {
        10: {
            70: 88,
            80: 98,
            100: 125,
            120: 153,
            150: 183,
        },
        12: {
            70: 105,
            80: 119,
            100: 205,
            120: 255,
            150: 305,
        },
        16: {
            70: 106,
            80: 156,
            100: 206,
            120: 256,
            150: 306,
        },
        18: {
            70: 103,
            80: 153,
            100: 203,
            120: 253,
            150: 303,
        },
    },
    veneer: {
        10: {
            70: 100,
            80: 150,
            100: 200,
            120: 250,
            150: 300,
        },
        12: {
            70: 105,
            80: 155,
            100: 205,
            120: 255,
            150: 305,
        },
        16: {
            70: 106,
            80: 156,
            100: 206,
            120: 256,
            150: 306,
        },
        18: {
            70: 103,
            80: 153,
            100: 203,
            120: 253,
            150: 303,
        },
    },
    dyed: {
        10: {
            70: 88,
            80: 98,
            100: 125,
            120: 153,
            150: 183,
        },
        12: {
            70: 105,
            80: 119,
            100: 149,
            120: 179,
            150: 219,
        },
        16: {
            70: 149,
            80: 167,
            100: 213,
            120: 255,
            150: 318,
        },
        18: {
            70: 163,
            80: 183,
            100: 231,
            120: 279,
            150: 338,
        },
    }
}
const rakeTree = {
    oak: {
        20: {
            30: 140,
            40: 160,
            50: 190,
            60: 210,
        },
        25: {
            30: 175,
            40: 200,
            50: 238,
            60: 270,
        },
        40: {
            30: 280,
            40: 320,
            50: 380,
            60: 432,
        },
        45: {
            30: 315,
            40: 360,
            50: 428,
            60: 486,
        },
    },
    ash: {
        20: {
            30: 130,
            40: 150,
            50: 180,
            60: 200,
        },
        25: {
            30: 162,
            40: 188,
            50: 225,
            60: 250,
        },
        40: {
            30: 260,
            40: 300,
            50: 360,
            60: 400,
        },
        45: {
            30: 290,
            40: 338,
            50: 405,
            60: 455,
        },
    },
    beech: {
        20: {
            30: 100,
            40: 120,
            50: 150,
            60: 180,
        },
        25: {
            30: 125,
            40: 150,
            50: 187,
            60: 225,
        },
        40: {
            30: 200,
            40: 240,
            50: 300,
            60: 360,
        },
        45: {
            30: 225,
            40: 270,
            50: 338,
            60: 405,
        },
    },
}
const rakeMDF = { // временно категории уходят, поэтому все цены на МДФ в dyed
    finish: {
        10: {
            70: 88,
            80: 98,
            100: 125,
            120: 153,
            150: 183,
        },
        12: {
            70: 105,
            80: 119,
            100: 205,
            120: 255,
            150: 305,
        },
        16: {
            70: 106,
            80: 156,
            100: 206,
            120: 256,
            150: 306,
        },
        18: {
            70: 103,
            80: 153,
            100: 203,
            120: 253,
            150: 303,
        },
    },
    veneer: {
        10: {
            70: 100,
            80: 150,
            100: 200,
            120: 250,
            150: 300,
        },
        12: {
            70: 105,
            80: 155,
            100: 205,
            120: 255,
            150: 305,
        },
        16: {
            70: 106,
            80: 156,
            100: 206,
            120: 256,
            150: 306,
        },
        18: {
            70: 103,
            80: 153,
            100: 203,
            120: 253,
            150: 303,
        },
    },
    dyed: {
        20: {
            20: 129,
            30: 139,
            40: 149,
            50: 163,
            60: 199,
            80: 259,
            90: 318,
            100: 338,
        },
        25: {
            20: 149,
            30: 169,
            40: 179,
            50: 199,
            60: 239,
            80: 308,
            90: 368,
            100: 388,
        },
        30: {
            20: 159,
            30: 179,
            40: 199,
            50: 219,
            60: 259,
            80: 338,
            90: 408,
            100: 428,
        },
        40: {
            20: 338,
            30: 368,
            40: 388,
            50: 418,
            60: 517,
            80: 677,
            90: 828,
            100: 880,
        },
        50: {
            20: 388,
            30: 438,
            40: 466,
            50: 517,
            60: 621,
            80: 806,
            90: 955,
            100: 1009,
        },
    }
}
const trimTree = {
    oak: {
        12: {
            60: 252,
            70: 270,
            80: 288,
            90: 300,
            100: 330,
        },
        14: {
            60: 294,
            70: 315,
            80: 336,
            90: 350,
            100: 385,
        },
        16: {
            60: 336,
            70: 360,
            80: 384,
            90: 400,
            100: 440,
        },
        20: {
            60: 420,
            70: 450,
            80: 480,
            90: 500,
            100: 550,
        },
    },
    ash: {
        10: {
            60: 216,
            70: 228,
            80: 240,
            90: 250,
            100: 262,
        },
        12: {
            60: 260,
            70: 274,
            80: 288,
            90: 300,
            100: 315,
        },
        16: {
            60: 346,
            70: 356,
            80: 384,
            90: 400,
            100: 420,
        },
        18: {
            60: 390,
            70: 411,
            80: 432,
            90: 450,
            100: 472,
        },
    },
    beech: {
        10: {
            60: 115,
            70: 131,
            80: 145,
            90: 162,
            100: 262,
        },
        12: {
            60: 138,
            70: 158,
            80: 175,
            90: 195,
            100: 315,
        },
        16: {
            60: 184,
            70: 210,
            80: 233,
            90: 260,
            100: 420,
        },
        18: {
            60: 207,
            70: 237,
            80: 262,
            90: 292,
            100: 472,
        },
    },
}
const trimMDF = { // временно категории уходят, поэтому все цены на МДФ в dyed
    finish: {
        10: {
            70: 88,
            80: 98,
            100: 125,
            120: 153,
            150: 183,
        },
        12: {
            70: 105,
            80: 119,
            100: 205,
            120: 255,
            150: 305,
        },
        16: {
            70: 106,
            80: 156,
            100: 206,
            120: 256,
            150: 306,
        },
        18: {
            70: 103,
            80: 153,
            100: 203,
            120: 253,
            150: 303,
        },
    },
    veneer: {
        10: {
            70: 100,
            80: 150,
            100: 200,
            120: 250,
            150: 300,
        },
        12: {
            70: 105,
            80: 155,
            100: 205,
            120: 255,
            150: 305,
        },
        16: {
            70: 106,
            80: 156,
            100: 206,
            120: 256,
            150: 306,
        },
        18: {
            70: 103,
            80: 153,
            100: 203,
            120: 253,
            150: 303,
        },
    },
    dyed: {
        10: {
            60: 438,
            70: 478,
            80: 517,
            90: 537,
            100: 557,
        },
        12: {
            60: 478,
            70: 517,
            80: 557,
            90: 577,
            100: 597,
        },
        16: {
            60: 517,
            70: 537,
            80: 577,
            90: 617,
            100: 637,
        },
        18: {
            60: 557,
            70: 557,
            80: 617,
            90: 657,
            100: 677,
        },
    }
}

const getItemFromTree = (tree, keys, idx = 0) => {
    if (idx === keys.length - 1 || tree[keys[idx]] === undefined) {
        return tree[keys[idx]]
    } else {
        return getItemFromTree(tree[keys[idx]], keys, ++idx)
    }
}
const initRangeFillLower = () => {
    new WebkitInputRangeFillLower({
        selectors: [
            "range-height-plintus",
            "range-thickness-plintus",
            "range-height-rake",
            "range-thickness-rake",
            "range-height-trim",
            "range-thickness-trim",
        ],
        color: "#0095F6"
    });
}
initRangeFillLower()
$(".liquidation__btn.contact").click(() => {
    $("#connect-popup .popup__title").html("Связаться с нами")
    openPopup("connect-popup")
    enableClosingPopupOnOverlayClick("connect-popup", "popup__body")
})
$(".des").click(() => {
    isCooperation = true
    $("#connect-popup .popup__title").html("Сотрудничество")
    openPopup("connect-popup")
    enableClosingPopupOnOverlayClick("connect-popup", "popup__body")
})
$(".building__btn").click((e) => {
    openPopup("build-popup")
    enableClosingPopupOnOverlayClick("build-popup", "popup__body")
    const id = $(e.currentTarget).attr("id")
    switch (id) {
        case "plintus-btn":
            buildingData.name = "Плинтус"
            break;
        case "rake-btn":
            buildingData.name = "Рейка"
            break;
        case "trim-btn":
            buildingData.name = "Наличник"
            break;
        default:
            break;
    }
})

const openPopup = (id) => {
    $popup = $("#" + id)
    $popup.removeClass("_hidden")
    disableScroll()
}
const closePopup = (id) => {
    $popup = $("#" + id)
    $popup.addClass("_hidden")
    enableScroll()
}
const enableClosingPopupOnOverlayClick = (popupId, popupBodyClass) => {
    $("#" + popupId).click((e) => {
        const $target = $(e.target)

        if ($target.closest("." + popupBodyClass).length === 0) {
            closePopup(popupId)
        }
    })
}

// scroll disabling
// left: 37, up: 38, right: 39, down: 40,
// spacebar: 32, pageup: 33, pagedown: 34, end: 35, home: 36
var keys = {
    37: 1,
    38: 1,
    39: 1,
    40: 1
};

function preventDefault(e) {
    e.preventDefault();
}

function preventDefaultForScrollKeys(e) {
    if (keys[e.keyCode]) {
        preventDefault(e);
        return false;
    }
}

// modern Chrome requires { passive: false } when adding event
var supportsPassive = false;
try {
    window.addEventListener("test", null, Object.defineProperty({}, 'passive', {
        get: function () {
            supportsPassive = true;
        }
    }));
} catch (e) {}

var wheelOpt = supportsPassive ? {
    passive: false
} : false;
var wheelEvent = 'onwheel' in document.createElement('div') ? 'wheel' : 'mousewheel';

// call this to Disable
function disableScroll() {
    window.addEventListener('DOMMouseScroll', preventDefault, false); // older FF
    window.addEventListener(wheelEvent, preventDefault, wheelOpt); // modern desktop
    window.addEventListener('touchmove', preventDefault, wheelOpt); // mobile
    window.addEventListener('keydown', preventDefaultForScrollKeys, false);
}

// call this to Enable
function enableScroll() {
    window.removeEventListener('DOMMouseScroll', preventDefault, false);
    window.removeEventListener(wheelEvent, preventDefault, wheelOpt);
    window.removeEventListener('touchmove', preventDefault, wheelOpt);
    window.removeEventListener('keydown', preventDefaultForScrollKeys, false);
}


let isEnableMoving = true

$(window).scroll(function () {
    const menuOffset = document.querySelector(".menu").offsetTop + window.innerHeight
    const headerHeight = getHeaderHeight()
    const menuHeight = 70
    const scrollTop = $(window).scrollTop()
    if (scrollTop < window.innerHeight || scrollTop > (menuOffset - headerHeight)) {
        // if (!isEnableMoving) return 
        // if (scrollTop < menuOffset) {
        //     // $('.header').addClass('_absolute');
        //     // $('.header').removeClass('_fixed');
        // } else {
            $('.header').removeClass('_fixed');
            // $('.header').removeClass('_absolute');
            $('.header_fake').css("display", "none");
        // }
    } else {
        $('.header_fake').css("display", "block");
        $('.header').addClass('_fixed');
        isEnableMoving = true
    }
})

const getHeaderHeight = () => {
    if (window.matchMedia("(min-width: 600px)").matches) {
        return 122
    } else {
        return 85
    }
}
const connectPopupForm = document.getElementById('connect-popup-form');
const questionsForm = document.getElementById('questions-form');
const deliveryForm = document.getElementById('delivery-form');
const buildPopupForm = document.getElementById('build-popup-form');

connectPopupForm.addEventListener('submit', (e) => formSend(e, connectPopupForm));
buildPopupForm.addEventListener('submit', (e) => formSend(e, buildPopupForm));
deliveryForm.addEventListener('submit', (e) => formSend(e, deliveryForm));
questionsForm.addEventListener('submit', (e) => formSend(e, questionsForm));
let isCooperation = false

async function formSend(e, form) {
	e.preventDefault();

	let formData = new FormData(form);
	// let error = formValidate(form);
	let error = null

	if (form.id === "build-popup-form") {
		for (const key in buildingData) {
			if (Object.hasOwnProperty.call(buildingData, key)) {
				const element = buildingData[key];
				formData.append(key, element)
			}
		}
	}
	if (isCooperation) {
		formData.append("cooperation", true)
	}

	if (!error) {
		form.classList.add('_sending');
		let response = await fetch('sendmail.php', {
			method: 'POST',
			body: formData
		});
		if (response.ok) {
			let result = await response.json();
			showSuccessModal()
			form.reset();
			form.classList.remove('_sending');
		} else {
			showFailModal()
			form.classList.remove('_sending');
		}
	} else {
		// ...
	}
}

const showSuccessModal = () => {
	// показ и автозакрытие попапа с сообщением об успехе
	if ($("div.success").hasClass("_visible")) {
		// ...
	} else {
		$("div.success").addClass("_visible")
		$("div.success").removeClass("_hidden")
		setTimeout(() => {
			$("div.success").removeClass("_visible")
			$("div.success").addClass("_hidden")
		}, 2500)
	}
}

const showFailModal = () => {
	// показ и автозакрытие попапа с сообщением об ошибке
	if ($("div.fail").hasClass("_visible")) {
		// ...
	} else {
		$("div.fail").addClass("_visible")
		$("div.fail").removeClass("_hidden")
		setTimeout(() => {
			$("div.fail").removeClass("_visible")
			$("div.fail").addClass("_hidden")
		}, 2500)
	}
}

function formValidate(form) {
	// валидация формы
	let error = 0; // количество ошибок
	let formReq = document.querySelectorAll('._req'); // обязательные поля ввода

	for (let index = 0; index < formReq.length; index++) {
		const input = formReq[index];

		if (!isChild(form, input)) continue; // если это поле не из этой формы, то пропускаем

		formRemoveError(input); // очищаем прошлые ошибки, на всякий случай

		if (input.getAttribute("type") === "checkbox" && input.checked === false) {
			// если это чекбокс и он пустой
			formAddError(input);
			error++;
			input.addEventListener("change", () => {
				// убираем ошибку, если пользователь ставит галочку
				formRemoveError(input)
			})
			break; // выходим, т.к. хотим показывать ошибки по очереди, а не все сразу
		} else {
			// если это просто input
			if (input.value === '') {
				formAddError(input);
				error++;
				input.addEventListener("keyup", () => {
					// убираем ошибку, если пользователь начинает что-то вводить
					formRemoveError(input)
				})
				break;
			}
		}
	}
	return error;
}

function formAddError(input) {
	input.parentElement.classList.add('_error');
}

function formRemoveError(input) {
	input.parentElement.classList.remove('_error');
}

function isChild(parent, child) {
	// проверяет на наличие дочернего элемента child у parent
	if (parent.contains(child)) return true;
	return false;
}
})